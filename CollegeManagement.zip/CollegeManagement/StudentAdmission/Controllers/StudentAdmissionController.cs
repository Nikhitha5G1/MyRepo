﻿using Microsoft.AspNetCore.Mvc;
using StudentAdmission.Models;
using System;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StudentAdmission.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class StudentAdmissionController : ControllerBase
	{
		// GET: api/<StudentAdmissionController>
		[HttpGet]
		public IEnumerable<StudentAdmissionDetailsModel> Get()
		{
			StudentAdmissionDetailsModel admissionObj1 = new StudentAdmissionDetailsModel();
			StudentAdmissionDetailsModel admissionObj2 = new StudentAdmissionDetailsModel();
			admissionObj1.StudentId = 1;
			admissionObj1.StudentName = "Steve";
			admissionObj1.StudentClass = "X";
			admissionObj1.DateOfJoining = DateTime.Now;
			admissionObj2.StudentId = 2;
			admissionObj2.StudentName = "Dustybun";
			admissionObj2.StudentClass = "IX";
			admissionObj2.DateOfJoining = DateTime.Now;
			List<StudentAdmissionDetailsModel> listobj = new List<StudentAdmissionDetailsModel>
			{
				admissionObj1,
				admissionObj2

			};
			return listobj;
		}

		// GET api/<StudentAdmissionController>/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		// POST api/<StudentAdmissionController>
		[HttpPost]
		public void Post([FromBody] string value)
		{
		}

		// PUT api/<StudentAdmissionController>/5
		[HttpPut("{id}")]
		public void Put(int id, [FromBody] string value)
		{
		}

		// DELETE api/<StudentAdmissionController>/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}
