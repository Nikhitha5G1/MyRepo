﻿using System;

namespace StudentAdmission.Models
{
	public class StudentAdmissionDetailsModel
	{
		public int StudentId { get; set; }
		public string StudentName { get; set; }
		public string StudentClass { get; set; }
		public DateTime DateOfJoining { get; set; }
	}
}
