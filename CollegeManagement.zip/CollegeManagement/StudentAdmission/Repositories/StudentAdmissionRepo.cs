﻿using StudentAdmission.Models;
using System.Collections.Generic;

namespace StudentAdmission.Repositories
{
	public class StudentAdmissionRepo : IStudentAdmissionRepo
	{

		public string AddnewAdmission(StudentAdmissionDetailsModel admission)
		{
			throw new System.NotImplementedException();
		}

		public string DeleteAdmission(int admissionid)
		{
			throw new System.NotImplementedException();
		}

		public StudentAdmissionDetailsModel GetAdmissionsById(int id)
		{
			throw new System.NotImplementedException();
		}

		public List<StudentAdmissionDetailsModel> GetAllAdmissions()
		{
			throw new System.NotImplementedException();
		}

		public string UpdateAdmission(StudentAdmissionDetailsModel admission)
		{
			throw new System.NotImplementedException();
		}
	}
}
