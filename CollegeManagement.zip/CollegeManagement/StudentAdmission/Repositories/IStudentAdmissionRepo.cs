﻿using StudentAdmission.Models;
using System.Collections.Generic;

namespace StudentAdmission.Repositories
{
	public interface IStudentAdmissionRepo
	{
		List<StudentAdmissionDetailsModel> GetAllAdmissions();
		StudentAdmissionDetailsModel GetAdmissionsById(int id);
		string AddnewAdmission(StudentAdmissionDetailsModel admission);
		string UpdateAdmission(StudentAdmissionDetailsModel admission);
		string DeleteAdmission(int admissionid);
	}
}
