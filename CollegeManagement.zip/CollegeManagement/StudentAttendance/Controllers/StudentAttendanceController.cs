﻿using Microsoft.AspNetCore.Mvc;
using StudentAttendance.Models;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StudentAttendance.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class StudentAttendanceController : ControllerBase
	{
		// GET: api/<StudentAttendanceController>
		[HttpGet]
		public IEnumerable<StudentAttendanceDetailsModel> Get()
		{
			StudentAttendanceDetailsModel attendanceobj1 = new StudentAttendanceDetailsModel();
			StudentAttendanceDetailsModel attendanceobj2 = new StudentAttendanceDetailsModel();
			attendanceobj1.StudentId = 1;
			attendanceobj1.StudentName = "Steve";
			attendanceobj1.AttendancePercentage = 83.01;
			attendanceobj2.StudentId = 2;
			attendanceobj2.StudentName = "Dustybun";
			attendanceobj2.AttendancePercentage = 78.09;
			List<StudentAttendanceDetailsModel> listObj = new List<StudentAttendanceDetailsModel>
			{
				attendanceobj1,
				attendanceobj2
			};
			return listObj;
		}

		// GET api/<StudentAttendanceController>/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		// POST api/<StudentAttendanceController>
		[HttpPost]
		public void Post([FromBody] string value)
		{
		}

		// PUT api/<StudentAttendanceController>/5
		[HttpPut("{id}")]
		public void Put(int id, [FromBody] string value)
		{
		}

		// DELETE api/<StudentAttendanceController>/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}
