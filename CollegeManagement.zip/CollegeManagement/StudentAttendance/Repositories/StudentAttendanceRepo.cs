﻿using StudentAttendance.Models;
using System.Collections.Generic;

namespace StudentAttendance.Repositories
{
	public class StudentAttendanceRepo : IStudentAttendanceRepo
	{
		public string AddnewAttendance(StudentAttendanceDetailsModel attendance)
		{
			throw new System.NotImplementedException();
		}

		public string DeleteAttendance(int attendanceid)
		{
			throw new System.NotImplementedException();
		}

		public StudentAttendanceDetailsModel GetAttendanceById()
		{
			throw new System.NotImplementedException();
		}

		public List<StudentAttendanceDetailsModel> GetStudentAttendance()
		{
			throw new System.NotImplementedException();
		}

		public string UpdateAttendance(StudentAttendanceDetailsModel attendance)
		{
			throw new System.NotImplementedException();
		}
	}
}
