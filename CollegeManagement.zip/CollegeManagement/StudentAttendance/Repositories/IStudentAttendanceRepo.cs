﻿using StudentAttendance.Models;
using System.Collections.Generic;

namespace StudentAttendance.Repositories
{
	public interface IStudentAttendanceRepo
	{
		List<StudentAttendanceDetailsModel> GetStudentAttendance();
		StudentAttendanceDetailsModel GetAttendanceById();
		string AddnewAttendance(StudentAttendanceDetailsModel attendance);
		string UpdateAttendance(StudentAttendanceDetailsModel attendance);
		string DeleteAttendance(int attendanceid);
	}
}
